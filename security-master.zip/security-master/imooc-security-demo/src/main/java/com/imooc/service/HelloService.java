/**
 * 
 */
package com.imooc.service;

/**
 * @author zhailiang
 *
 */
public interface HelloService {
	
	String greeting(String name);

}
