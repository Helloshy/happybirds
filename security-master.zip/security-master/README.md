# security

慕课网 http://coding.imooc.com/class/134.html 的源代码

集成 spring securit, spring security oauth 和 spring social，实现 用户名密码登录，手机验证码登录，社交账号登录，基于jwt的sso，集群session管理等功能。
