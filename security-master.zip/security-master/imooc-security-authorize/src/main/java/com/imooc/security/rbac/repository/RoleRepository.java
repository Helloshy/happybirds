/**
 * 
 */
package com.imooc.security.rbac.repository;

import org.springframework.stereotype.Repository;

import com.imooc.security.rbac.domain.Role;

/**
 * @author zhailiang
 *
 */
@Repository
public interface RoleRepository extends ImoocRepository<Role> {

}
