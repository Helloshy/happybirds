/**
 * 
 */
package com.imooc.security.rbac.domain;

/**
 * @author zhailiang
 *
 */
public enum ResourceType {
	
	MENU,
	
	BUTTON

}
