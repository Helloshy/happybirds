/**
 * 
 */
package com.imooc.security.rbac.repository;

import org.springframework.stereotype.Repository;

import com.imooc.security.rbac.domain.RoleAdmin;

/**
 * @author zhailiang
 *
 */
@Repository
public interface RoleAdminRepository extends ImoocRepository<RoleAdmin> {

}
