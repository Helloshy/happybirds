/**
 * 
 */
package com.imooc.security.rbac.dto;

/**
 * @author zhailiang
 *
 */
public class AdminCondition {
	
	private String username;

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	
}
