/**
 * 
 */
/**
 * @author zhailiang
 *
 */
package com.imooc.sso.client;