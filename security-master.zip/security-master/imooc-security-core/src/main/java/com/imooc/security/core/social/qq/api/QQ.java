/**
 * 
 */
package com.imooc.security.core.social.qq.api;

/**
 * @author zhailiang
 *
 */
public interface QQ {
	
	QQUserInfo getUserInfo();

}
